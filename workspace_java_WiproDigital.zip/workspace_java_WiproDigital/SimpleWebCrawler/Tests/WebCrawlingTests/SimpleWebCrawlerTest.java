/**
 * 
 */
package WebCrawlingTests;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Rafael O. Cordova
 *
 */
public class SimpleWebCrawlerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}



	/**
	 *  System Test for crawling
	 *  Function Crawl returns void and  
	 */
	@Test
	public final void Test_Crawel() {
		// TO DO:
		// Algorithm:
		// redirect output to a file
		// make file 
		
		
		 
	}

}

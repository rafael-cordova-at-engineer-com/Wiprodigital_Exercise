package WebCrawling;
/**
 * 
 */

import Text_Extraction.URLs;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

// For secure web connections
import java.net.*;
import java.io.*;
import javax.net.ssl.HttpsURLConnection;
//import java.util.Base64;
//import java.util.Base64.Encoder;

/**
 * @author Rafael O. Cordova
 *
 */
public final class SimpleWebCrawler {
	private static String domain_name 		= null;
	private static String server_name 		= null;
	private static String url_path 			= null;
	private static int recursion_level		= 0;
	private static int pages_navigated		= 0;
	
	private static StringBuffer all_links	= new StringBuffer();
	private static StringBuffer all_pages	= new StringBuffer();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Entered: Simple Web Crawler");
		
		if (args.length > 0)
		{
			domain_name = URLs.Get_URL_Domain(args[0]); 
			server_name = URLs.Get_URL_Server_Name(args[0]);
			url_path = URLs.Get_URL_Path(args[0]);
			
			Crawl(args[0]);	
		}
		else
		{
			System.out.println("Error: Missing top level host URL.");			
		}

		
		System.out.println("Exiting: Simple Web Crawler");

	}
	
	
	// --------------------------------------------------------------------//
	//
	// --------------------------------------------------------------------//
	/** TO DO: expansion
	public static final void Invoke_Get_Static_Address()
	{
		new Text_Extraction.URLs();
		
		System.out.println(
				URLs.Get_Static_Addresses(
						URLs.Make_Static_Address()));
	}
**/
	
	// --------------------------------------------------------------------//
	//
	// --------------------------------------------------------------------//
	public static final void Crawl(String url_text)
	{

		// 
		String web_content		= null;
		String returned_urls 	= "";
		String[] found_urls  	= null;
		StringBuffer page_urls	= new StringBuffer();

		
		new Text_Extraction.URLs();
						
		recursion_level += 1;
		System.out.print  ("-----------------------------------------");
		System.out.print  ("-----------------------------------------" + "\n");
		System.out.println("       Recursion Level: " + recursion_level);
		System.out.print  ("-----------------------------------------");
		System.out.print  ("-----------------------------------------" + "\n");
			
		pages_navigated += 1;
		System.out.print  ("-----------------------------------------");
		System.out.print  ("-----------------------------------------" + "\n");
		System.out.println("       Processing Page: " + pages_navigated);
		System.out.print  ("-----------------------------------------");
		System.out.print  ("-----------------------------------------" + "\n");
		
		if(pages_navigated == 22)
		{
			System.out.print  ("-----------------------------------------" + "\n");	
		
		}

		if(url_text.contains("https"))
		{
			web_content = GetSecureContent(url_text);
		}
		else if(url_text.contains("http:"))
		{
			web_content = GetUnsecuredContent(url_text);
		}
		else if(url_text.contains("file:"))
		{
			web_content = GetFileContent(url_text);
		}
		
		//--------------------------------//
		//
		//--------------------------------//
		if(url_text.contains("file:"))
		{
			returned_urls = URLs.Get_Enclosed_Hyperlinks(web_content);
		}
		else
		{
			returned_urls = URLs.Get_HREF_Hyperlinks(web_content);
			
			System.out.print("\n\n\n");
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");
			System.out.println("       Web Page:\t" + url_text);
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");

			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");				
			System.out.println("                                Web Pages Hyperlinks");
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");

			System.out.println(returned_urls);

			found_urls = returned_urls.split("\n");
			for(String link : found_urls)
			{   
				String all_strings = new String(all_links);
				if( !(all_strings.contains(link)))
				{
					all_links.append(link + "\n");					
				}
				
				String url_strings = new String(all_pages);
				if( !(url_strings.contains(link)))
				{
					page_urls.append(link + "\n");
					all_pages.append(link + "\n");
				}	
			}
			
			//
			returned_urls = URLs.Get_IMG_Hyperlinks(web_content);

			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");	
			System.out.println("                                       Images");
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");

			System.out.println(returned_urls);

			found_urls = returned_urls.split("\n");
			for(String link : found_urls)
			{   String all_strings = new String(all_links);
				if( !(all_strings.contains(link)))
				{
					all_links.append(link + "\n");			
				}								
			}
			
			//
			returned_urls = URLs.Get_Anchor_Hyperlinks(web_content);

			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");	
			System.out.println("                                       Anchors");
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");

			System.out.println(returned_urls);
			
			found_urls = returned_urls.split("\n");
			for(String link : found_urls)
			{   String all_strings = new String(all_links);
				if( !(all_strings.contains(link)))
				{
					all_links.append(link + "\n");				
				}								
			}
			
			
			//
			returned_urls = URLs.Get_Scripts_Hyperlinks(web_content);

			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");	
			System.out.println("                                        Scripts");
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");

			System.out.println(returned_urls);		
			
			System.out.print  ("-----------------------------------------");
			System.out.print("-----------------------------------------" + "\n");	
		
			found_urls = returned_urls.split("\n");
			for(String link : found_urls)
			{   String all_strings = new String(all_links);
				if( !(all_strings.contains(link)))
				{
					all_links.append(link + "\n");				
				}								
			}
			
			
			// Navigate to linked web pages
			String page_strings = new String(page_urls);
			found_urls = page_strings.split("\n");
			
			for( String found : found_urls)
			{
				if(    !(found.equals(""))
					&& (URLs.Get_URL_Domain(found).equals(domain_name)))
				{
					if(!(found.equals(url_text)))
					{
						String found_server = URLs.Get_URL_Server_Name(found);
						String path_text	= URLs.Get_URL_Path(found);
						if (    !(path_text.equals(url_path))
							 || !(found_server.equals(server_name)))
						{
 							Crawl(found);
						}
					}
				}								
			}
		}

			
		// 
		if (recursion_level == 1)
		{
			String all_strings = new String(all_links);
			found_urls = all_strings.split("\n");
			
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");
			System.out.println("       Total Links Found: " + found_urls.length);
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");
			for( String found : found_urls)
			{
				System.out.println(found);
			}
			System.out.print  ("-----------------------------------------");
			System.out.print  ("-----------------------------------------" + "\n");
		}
		//TO DELETE: URLs.Get_Hyperlinks_From_HTML(GetSecureContent(url));

		recursion_level -= 1;
	}
	
	
	// --------------------------------------------------------------------//
	//
	// --------------------------------------------------------------------//
	public static final String GetUnsecuredContent(String address)
	{
		// Function scope variables
		String content = null;
		
		if( !(address.isEmpty()))
		{
			// Code block scope variables
			String response_line			= null;
			BufferedReader response_reader	= null; 
			HttpURLConnection connection	= null;
			
			try
			{
				connection 
					= (HttpURLConnection) 
						new URL(address).openConnection();
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}
						
			try
			{
				connection.setRequestMethod("GET");				
			}
			catch (IOException error)
			{	
				System.out.println(error.getMessage());
			}


			try
			{
				response_reader
					= new BufferedReader
						(
							new InputStreamReader
								(connection.getInputStream())
						);
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}

			
			StringBuffer content_buffer 
				= new StringBuffer();
			
			try
			{
				while ((response_line = response_reader.readLine()) != null) {
					content_buffer.append(response_line);
				}
				
				content = new String(content_buffer);
				response_reader.close();
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}

		}				
				
		return content;
	}
	
	
	// --------------------------------------------------------------------//
	//
	// --------------------------------------------------------------------//
	public static final String GetSecureContent(String address)
	{
		String content = null;

		//String userName = "admin";
		//String password = "admin";
		//String authentication = userName + ':' + password;
	
		URL address_url = null;
		try
		{
			address_url = new URL(address);
		}
		catch (MalformedURLException error)
		{
			System.out.println(error.getMessage());
		}

		HttpURLConnection connection = null;
		// open HTTPS connection
		try
		{
			connection = (HttpsURLConnection) address_url.openConnection();
		}
		catch (IOException error)
		{
			System.out.println(error.getMessage());
		}
		
		connection.setRequestProperty("Content-Type", "text/plain; charset=\"utf8\"");

		
		try
		{
			connection.setRequestMethod("POST");
		}
		catch (ProtocolException error)
		{
			System.out.println(error.getMessage());
		}

		// execute HTTPS request
		int returnCode = 0;
		try
		{
			returnCode = connection.getResponseCode();
		}
		catch (IOException error)
		{
			System.out.println(error.getMessage());
		}
		
		InputStream connectionIn = null;
		
		if (returnCode==200)
		{
			try
			{
				connectionIn = connection.getInputStream();
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}
		}
		else
		{
			connectionIn = connection.getErrorStream();
		}
		
		// print resulting stream
		BufferedReader buffer = new BufferedReader(new InputStreamReader(connectionIn));
		String response_line = "";
		StringBuffer content_buffer = new StringBuffer();
		
		while ( response_line  != null)
		{
			try
			{
				response_line = buffer.readLine();
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}
			
			content_buffer.append(response_line);
		}
		
		try
		{
			content = new String(content_buffer);
			buffer.close();
		}
		catch (IOException error)
		{
			System.out.println(error.getMessage());
		}	
		
		return content;
	}
	
	
	// --------------------------------------------------------------------//
	//
	// --------------------------------------------------------------------//
	public static final String GetFileContent(String address)
	{
		// Function scope variables
		String content = null;
				
		if( !(address.isEmpty()))
		{
			// Code block scope variables
			String response_line			= null;
			BufferedReader response_reader	= null; 
			
			try
			{
				FileReader filer = new FileReader(address);	
				response_reader
					= new BufferedReader
						(
								filer					
						);
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}

			
			StringBuffer content_buffer 
				= new StringBuffer();
			
			try
			{
				while ((response_line = response_reader.readLine()) != null) {
					content_buffer.append(response_line);
				}
				
				content = new String(content_buffer);
				response_reader.close();
			}
			catch (IOException error)
			{
				System.out.println(error.getMessage());
			}

		}				
				
		return content;
	}
}

/**
 * 
 */
package Text_Extraction;

//import java.io.BufferedReader;

/**
 * @author Rafael O. Cordova
 *
 */
public final class URLs
{
	// --------------------------------------------------------------------//
	// Reference: test_Get_Static_Addresses()
	// --------------------------------------------------------------------//
	public static final String Get_Static_Addresses(String text)
	{
		StringBuffer page_content = new StringBuffer("<HTML>");
		
		page_content.append("Get_Static_Address is Not implemented yet");
		page_content.append("<HTML\\>");
		
		return new String(page_content);
		//return new String(text);
	}

	// --------------------------------------------------------------------//
	// Reference: test_Make_Static_Addresses
	// --------------------------------------------------------------------//
	public static final String Make_Static_Address()
	{
		StringBuffer page_content = new StringBuffer("<HTML>");
		
		page_content.append("Make_Static_Address is Not implemented yet");
		page_content.append("<HTML\\>");
		
		return new String(page_content);
	}
	
	// --------------------------------------------------------------------//
	// Reference: Intg_Tests_IsHyperlink
	// --------------------------------------------------------------------//
	public static final boolean Is_Hyperlink(String address)
	{
		boolean result = false;
		if(Get_URL_Protocol(address) != null)
		{
			result = true;
		}
		
		return result;
	}

	
	// --------------------------------------------------------------------//
	// Reference: Unit_Tests_Get_URL_Protocol()
	// --------------------------------------------------------------------//
	public static final String Get_URL_Protocol(String address)
	{
		// Function scope variables
		String protocol_spec = null;
		String valid_protocols 
					=		"http\n"
						+	"https\n";
		
		if ( 	(address != null) 
			&&	(address.length() > 0) )
		{
			// Processing block variables
			if( address.contains(":") )
			{
				protocol_spec = address.substring(0, address.indexOf(":"));
				if( !(valid_protocols.contains(protocol_spec)) )
				{
					protocol_spec = null;
				}
			}
		}		
			
		return protocol_spec;
	}
	
	// --------------------------------------------------------------------//
	// Reference: Unit_Tests_Get_URL_Server_Name()
	// --------------------------------------------------------------------//
	public static final String Get_URL_Server_Name(String address)
	{
	
		// Function scope variables
		String host_spec = null;
		String server_name = null;
		
		if (address != null)
		{
			// Processing block variables
			host_spec = address.substring(address.indexOf(":") + 2);
			host_spec = host_spec.substring(1);
			
			if(host_spec.contains("/"))
			{
				host_spec = host_spec.substring(0, host_spec.indexOf("/"));
			}
			
			server_name = host_spec.substring(0, host_spec.indexOf("."));
			host_spec = host_spec.substring(host_spec.indexOf(".") + ".".length());
			if(host_spec.indexOf(".") == -1)
			{
				server_name = "www"; 
			}
			
		}		
			
		return server_name;
	}
	
	// --------------------------------------------------------------------//
	// Reference: Unit_Tests_Get_URL_Domain()
	// --------------------------------------------------------------------//
	public static final String Get_URL_Domain(String address)
	{
	
		// Function scope variables
		String host_spec = null;
		String domain_name = null;
		
		if (address != null)
		{
			// Processing block variables
			host_spec = address.substring(address.indexOf(":") + 2);
			host_spec = host_spec.substring(1);
			
			if(host_spec.contains("/"))
			{
				host_spec = host_spec.substring(0, host_spec.indexOf("/"));
			}
			
			domain_name = host_spec.substring(host_spec.indexOf(".") + ".".length());
			if(domain_name.indexOf(".") == -1)
			{
				domain_name = host_spec; 
			}
			
		}		
			
		return domain_name;
	}
	
	// --------------------------------------------------------------------//
	// Reference: Unit_Tests_Get_URL_Path()
	// --------------------------------------------------------------------//
	public static final String Get_URL_Path(String address)
	{
	
		// Function scope variables
		String host_spec = null;
		String path_text = null;
		
		if (address != null)
		{
			// Processing block variables
			host_spec = address.substring(address.indexOf(":") + 2);
			host_spec = host_spec.substring(1);
			
			path_text = host_spec.substring(host_spec.indexOf(".") + ".".length());
			if(path_text.indexOf("/") == -1)
			{
				path_text = ""; 
			}
			else
			{
				path_text = path_text.substring(path_text.indexOf("/") + "/".length());
			}
			
		}		
			
		return path_text;
	}
	
	// --------------------------------------------------------------------//
	// Reference: Get_Enclosed_Hyperlinks()
	// --------------------------------------------------------------------//
	public static final String Get_Enclosed_Hyperlinks(String text)
	{
	
		// Function scope variables
		//String host_spec = null;
		
		String copy = new String(text);
		StringBuffer links = new StringBuffer();
		
		while(copy.indexOf("<") != -1)
		{
			copy = copy.substring(copy.indexOf("<") + 1);
			String eval_string 
				= new String
					(
						copy
							.substring
								(	  0
									, copy.indexOf(">") 
								)
								+ "\n"
					);
			String list_strings = new String (links);
			if( !(list_strings.contains(eval_string)))
			{
				if(Is_Hyperlink(eval_string))
				{
					links.append(eval_string);					
				}
								
			}
			copy = copy.substring(copy.indexOf(">") + 1);
		}
				
			
		return new String(links);
	}
	

	// --------------------------------------------------------------------//
	// Reference: Intg_Get_HREF_Hyperlinks()
	// --------------------------------------------------------------------//
	public static final String Get_HREF_Hyperlinks(String text)
	{	
		// Function scope variables
		//String host_spec = null;
		
		String copy = new String(text);
		StringBuffer links = new StringBuffer();

		// Search for web pages specs - href

		
		while(copy.indexOf("href") != -1)
		{
			copy = copy.substring(copy.indexOf("href") + 5);
			copy = copy.substring(copy.indexOf("\"") + 1);
			
			String eval_string 
				= new String
					(
						copy
							.substring
								(	  0
									, copy.indexOf("\"") 
								)
								+ "\n"
					);
			String list_strings = new String (links);
			if( !(list_strings.contains(eval_string)))
			{
				if(Is_Hyperlink(eval_string))
				{
					links.append(eval_string);					
				}
								
			}
			copy = copy.substring(copy.indexOf("\"") + 1);
		}
				
			
		return new String(links);
	}
	
	
	// --------------------------------------------------------------------//
	// Reference: Intg_Test_Get_IMG_Hyperlinks()
	// --------------------------------------------------------------------//
	public static final String Get_IMG_Hyperlinks(String text)
	{	
		// Function scope variables`
		//String host_spec = null;
		
		String copy = new String(text);
		StringBuffer links = new StringBuffer();

		// Search for images specs - <img ... src=

		
		while(copy.indexOf("img") != -1)
		{
			copy = copy.substring(copy.indexOf("<img") + 4);
			copy = copy.substring(copy.indexOf("src") + 3);
			copy = copy.substring(copy.indexOf("\"") + 1);
			
			String eval_string 
				= new String
					(
						copy
							.substring
								(	  0
									, copy.indexOf("\"") 
								)
								+ "\n"
					);
			String list_strings = new String (links);
			if( !(list_strings.contains(eval_string)))
			{
				if(Is_Hyperlink(eval_string))
				{
					links.append(eval_string);					
				}
								
			}
			copy = copy.substring(copy.indexOf("\"") + 1);
		}
				
			
		return new String(links);
	}
	
	
	// --------------------------------------------------------------------//
	// Reference: Intg_Test_Get_Anchor_Hyperlinks()
	// --------------------------------------------------------------------//
	public static final String Get_Anchor_Hyperlinks(String text)
	{	
		// Function scope variables
		//String host_spec = null;
		
		String copy = new String(text);
		StringBuffer links = new StringBuffer();

		// Search for anchor specs - <a url()
		String eval_text = "";
		String href_spec = "";
		String url_spec = "";
		
		while(copy.indexOf("<a") != -1)
		{
			copy = copy.substring(copy.indexOf("<a"));
			eval_text = copy.substring(copy.indexOf("<a"), copy.indexOf(">") + 1);
			
			copy = copy.substring(copy.indexOf(">"));
			
			if ((eval_text.indexOf("href") != -1))				
			{
				href_spec = eval_text.substring(eval_text.indexOf("href") + 4);
				href_spec = href_spec.substring(href_spec.indexOf("=") + 1);
				href_spec = href_spec.substring(href_spec.indexOf("\"") + 1); 
				
				href_spec = href_spec 
						.substring
							(	  0
								, href_spec.indexOf("\"") 
							)
							+ "\n";
				
				String list_strings = new String (links);
				if( !(list_strings.contains(href_spec)))
				{
					if(Is_Hyperlink(href_spec))
					{
						links.append(href_spec);					
					}								
				}
			}
			if ((eval_text.indexOf("url") != -1))				
			{
				url_spec = eval_text.substring(eval_text.indexOf("url") + "url".length());
				url_spec = url_spec.substring(url_spec.indexOf("(")   + "(".length());
				
				url_spec  = url_spec.substring(url_spec.indexOf("'")  + "'".length());
				url_spec = url_spec 
								.substring
									(	  0
										, url_spec.indexOf("'") 
									)
									+ "\n";

				String list_strings = new String (links);
				if( !(list_strings.contains(url_spec)))
				{
					if(Is_Hyperlink(url_spec))
					{
						links.append(url_spec);					
					}								
				}
			}
			
		}
			
		return new String(links);
	}
	

	// --------------------------------------------------------------------//
	// Reference: Intg_Test_Get_Scripts_Hyperlinks()
	// --------------------------------------------------------------------//
	public static final String Get_Scripts_Hyperlinks(String text)
	{	
		// Function scope variables
		//String host_spec = null;
		
		String copy = new String(text);
		StringBuffer links = new StringBuffer();
		String src_spec = "";
		// Search for scripts specs - <script

		
		while(copy.indexOf("<script") != -1)
		{
			copy = copy.substring(copy.indexOf("<script"));
			src_spec = copy.substring(copy.indexOf("<script") + "<script".length());
			src_spec = src_spec.substring(0, src_spec.indexOf(">"));
			copy = copy.substring(copy.indexOf(">"));

			
			// Only process static links
			if(src_spec.indexOf("src") != -1)
			{
				src_spec = src_spec.substring(src_spec.indexOf("src") + "src".length());
				src_spec = src_spec.substring(src_spec.indexOf("=") + "=".length());
				
				String delimeter = "";
				if(src_spec.indexOf("\"") != -1)
				{
					delimeter = "\"";
				}
				else if(src_spec.indexOf("'") != -1)
				{
					delimeter = "'";
				}
				src_spec = src_spec.substring(src_spec.indexOf(delimeter) + delimeter.length());
				
				String eval_string 
					= new String
						(
								src_spec
								.substring
									(	  0
										, src_spec.indexOf(delimeter) 
									)
									+ "\n"
						);
				String list_strings = new String (links);
				if( !(list_strings.contains(eval_string)))
				{
					if(Is_Hyperlink(eval_string))
					{
						links.append(eval_string);					
					}
									
				}
			}
		}
			
			
		return new String(links);
	}	
	
	
	// TO DO: future expansion for code readability
	/**
	// --------------------------------------------------------------------//
	//
	// --------------------------------------------------------------------//
	public static final boolean Is_Already_In_List(String text, String list)
	{				
		return !(list.contains(text));	
	}
	*/
}



/**
 * 
 */
package Text_Extraction_Testing;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import Text_Extraction.URLs;

/**
 * @author Rafael O. Cordova
 *
 */
public class TestURLsClass {
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link Text_Extraction.URLs#Get_Static_Addresses()}.
	 */
	@Test
	public final void test_Get_Static_Addresses() {
		/**
		System.out.println(
				URLs.Get_Static_Addresses(
						URLs.Make_Static_Address()));
		fail("Not yet implemented");
		*/
	}


	/**
	 * Test 
	 */
	@Test
	public final void test_Make_Static_Addresses() {
		/**
		System.out.println(URLs.Make_Static_Address());
		fail("Not yet implemented");
		**/
	}
	
	
	/**
	 * Unit  Tests for method Get_URL_Server_Name, 
	 * which returns the name of the server inn the host spec
	 * and the default 'www' otherwise
	 * 
	 *  Notice:
	 *      Assumes that url is valid
	 */
	@Test
	public final void Unit_Tests_Get_URL_Server_Name()
	{
		//Default server name
		assert URLs.Get_URL_Server_Name("http://wiprodigital.com").equals("www");
		
		// Returned server name as specified in url
		assert URLs.Get_URL_Server_Name("http://test.wiprodigital.com").equals("test");
		
		// Return std server names as specified
		assert URLs.Get_URL_Server_Name("http://www.wiprodigital.com").equals("www");
		
		// TO DO: address url validity
		//assert URLs.Get_URL_Server_Name("http//www.wiprodigital.com").equals("www");
	}
	
	/**
	 * Unit  Tests for method Get_URL_Protocol, 
	 * which returns the protocol name if the url has a protocol spec
	 * and null otherwise 
	 * 
	 * Currently weakly checks for 2 protocols only
	 * 	     http and https
	 *       substrings will return the protocol
	 *
	 * In the future:
	 * 		ftp, file, telnet and others in a well designed valid protocol list
	 * 
	 * To Do:
	 * 		 make a a well designed valid protocol list
	 * 
	 */
	@Test
	public final void Unit_Tests_Get_URL_Protocol()
	{
		// Well formed protocol spec
		assert URLs.Get_URL_Protocol("http://www.wiprodigital.com").equals("http");
		
		// Missing protocol delimeter
		assert URLs.Get_URL_Protocol("http//www.wiprodigital.com")  == null;
		
		// Missing a forward slash
		assert URLs.Get_URL_Protocol("http:/www.wiprodigital.com").equals("http");
		
		// Missing protocol
		assert URLs.Get_URL_Protocol("/www.wiprodigital.com")  		== null;
		
		// Not supported protocol
		assert URLs.Get_URL_Protocol("ftp:/www.wiprodigital.com") 	== null;
		
		// TO DO: address protocol validity
		assert URLs.Get_URL_Protocol("tp:/www.wiprodigital.com").equals("tp");

	}
	
	/**
	 * Unit  Tests for method Get_URL_Domain, 
	 * which returns the name of the domain in the host spec 
	 * 
	 *  Notice:
	 *      Assumes that url is valid
	 */
	@Test
	public final void Unit_Tests_Get_URL_Domain()
	{
		//Missing server name
		assert URLs.Get_URL_Domain("http://wiprodigital.com").equals("wiprodigital.com");
		
		// Weel formed url
		assert URLs.Get_URL_Domain("http://test.wiprodigital.com").equals("wiprodigital.com");
				
		// TO DO: address url validity
		//assert URLs.Get_URL_Domain("http//www.wiprodigital.com").equals("wiprodigital.com");
	}
	
	
	/**
	 * Unit  Tests for method Get_URL_Path, 
	 * which returns the path in the spec 
	 * empty string otherwise
	 * 
	 *  Notice:
	 *      Assumes that url is valid
	 */
	@Test
	public final void Unit_Tests_Get_URL_Path()
	{
		//Well formed url
		assert URLs.Get_URL_Path("http://wiprodigital.com/we_are_good").equals("we_are_good");
		
		//Extra forward slash at the end
		assert URLs.Get_URL_Path("http://wiprodigital.com/we_are_good/").equals("we_are_good/");

		// Missing path
		assert URLs.Get_URL_Path("http://test.wiprodigital.com").equals("");

		// Missing server
		assert URLs.Get_URL_Path("http://wiprodigital.com/we_are_good").equals("we_are_good");
		
		// TO DO: address url validity
		//assert URLs.Get_URL_Path("http//www.wiprodigital.comwe_are_good").equals("we_are_good");
	}
	
	
	/**
	 * Note Non UNIT
	 * Depends on UNIT Get_URL_Protocol()
	 * Integration Tests non Unit method Is_Hyperlink, 
	 * which returns true if the hyperlink has a specified protocol
	 * and false otherwise 
	 * 
	 * Currently supported protocols are
	 * 	     http and https
	 * 
	 * In the future:
	 * 		ftp, file, telnet and others in a well designed valid protocol list
	 * 
	 * To Do:
	 * 		 make a a well designed valid protocol list
	 * 
	 */
	@Test
	public final void Intg_Tests_IsHyperlink()
	{		
		assert URLs.Is_Hyperlink("http://www.wiprodigital.com") == true;
		assert URLs.Is_Hyperlink("http//www.wiprodigital.com")  == false;
	}
	
	/**
	 * Note Non UNIT
	 * Depends on UNIT Get_URL_Protocol()
	 * Integration Tests non Unit method Is_Hyperlink, 
	 * which returns true if the hyperlink has a specified protocol
	 * and false otherwise 
	 * 
	 * Currently supported protocols are
	 * 	     http and https
	 * 
	 * In the future:
	 * 		ftp, file, telnet and others in a well designed valid protocol list
	 * 
	 * To Do:
	 * 		 make a a well designed valid protocol list
	 * 
	 */
	@Test
	public final void test_Is_Hyperlink()
	{
		// well formed hyperlink
		assert URLs.Is_Hyperlink("http://www.wiprodigital.com") == true;
		
		// Missing colon
		assert URLs.Is_Hyperlink("http//www.wiprodigital.com")  == false;
		
		// Missing forward slash
		assert URLs.Is_Hyperlink("http:/www.wiprodigital.com")  == true;
		
		// Missing protocol
		assert URLs.Is_Hyperlink("/www.wiprodigital.com")  == false;
		
		// Mistyped Semi colon instead of colon
		assert URLs.Is_Hyperlink("http;//www.wiprodigital.com")  == false;

	}

	
	/**
	 * Note Non UNIT
	 * Depends on UNIT Is_Hyperlink()
	 * Integration Tests non Unit method Get_HREF_Hyperlinks, 
	 * which returns a string with hyperlinks, separated by newline characters
	 * Hyperlinks are extracted when detecting the 'href' HTML term
	 * 
	 * Empty string is returned if no navigatable links are found 
	 */
	@Test
	public final void Intg_Get_HREF_Hyperlinks()
	{
		String HTML_content = "";

		// Empty document
		assert URLs.Get_HREF_Hyperlinks(HTML_content).equals("");
		
		// One link document
		HTML_content = "<href=\"http://www.wiprodigital.com\">";
		assert URLs.Get_HREF_Hyperlinks(HTML_content).equals("http://www.wiprodigital.com" + "\n");

		// One unrecognizable link document
		HTML_content = "<url(\"http://www.wiprodigital.com\")";
		assert URLs.Get_HREF_Hyperlinks(HTML_content).equals("");
		
		// Two link document
		HTML_content 
			=    "<href=\"http://www.wiprodigital.com\">"
			   + "\n"
			   + "<href=\"http://wiprodigital.com\">";

		assert URLs.Get_HREF_Hyperlinks(HTML_content)
				.equals(
							  "http://www.wiprodigital.com"
							+ "\n"
							+ "http://wiprodigital.com" + "\n");

		// One good link and one not recognizable document
		HTML_content 
			=    "<href=\"http://www.wiprodigital.com\">"
			   + "\n"
			   + "<src=\"http://wiprodigital.com\">";

		assert URLs.Get_HREF_Hyperlinks(HTML_content)
				.equals("http://www.wiprodigital.com" + "\n");

	}
	
	
	/**
	 * Note Non UNIT
	 * Depends on UNIT Is_Hyperlink()
	 * Integration Tests non Unit method Get_IMG_Hyperlinks, 
	 * which returns a string with hyperlinks to images, separated by newline characters.
	 * Hyperlinks are extracted when detecting the 'img' tag and the 'src' HTML term
	 * An empty string is returned if no links are found. 
	 */
	@Test
	public final void Intg_Test_Get_IMG_Hyperlinks()
	{
		String HTML_content = "";

		// Empty document
		assert URLs.Get_IMG_Hyperlinks(HTML_content).equals("");
		
		// One link document
		HTML_content = "<img src=\"http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png\">";
		assert URLs.Get_IMG_Hyperlinks(HTML_content)
				.equals("http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png" + "\n");

		// One unrecognizable link document
		HTML_content = "<href src=\"http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png\">";
		assert URLs.Get_IMG_Hyperlinks(HTML_content).equals("");
		
		// Two link document
		HTML_content 
			=    "<img src=\"http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png\">"
			   + "\n"
			   + "<img src=\"http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/welcome.gif\">";

		assert URLs.Get_IMG_Hyperlinks(HTML_content)
				.equals(
							  "http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png"
							+ "\n"
							+ "http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/welcome.gif" + "\n");

		// One good link and one not recognizable document
		HTML_content 
			=    "<img src=\"http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png\">"
			   + "\n"
			   + "<href src=\"http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png\">";

		assert URLs.Get_IMG_Hyperlinks(HTML_content)
				.equals("http://www.wiprodigital.com/wp-content/themes/wiprodigital/images/logo.png" + "\n");

	}
	
	
	/**
	 * Note Non UNIT
	 * Depends on UNIT Is_Hyperlink()
	 * Integration Tests non Unit method Get_Anchor_Hyperlinks, 
	 * which returns a string with hyperlinks refered to by the anchor spec, separated by newline characters.
	 * Hyperlinks are extracted when detecting the <a' tag and the 'href' HTML attribute term
	 * An empty string is returned if no links are found. 
	 */
	@Test
	public final void Intg_Test_Get_Anchor_Hyperlinks()
	{
		String HTML_content = "";

		// Empty document
		assert URLs.Get_HREF_Hyperlinks(HTML_content).equals("");
		
		// One link document
		HTML_content = "<a href=\"http://www.wiprodigital.com\">";
		assert URLs.Get_HREF_Hyperlinks(HTML_content).equals("http://www.wiprodigital.com" + "\n");

		// One unrecognizable link document
		HTML_content = "<a url(\"http://www.wiprodigital.com\")";
		assert URLs.Get_HREF_Hyperlinks(HTML_content).equals("");
		
		// Two link document
		HTML_content 
			=    "<a href=\"http://www.wiprodigital.com\">"
			   + "\n"
			   + "<a href=\"http://wiprodigital.com\">";

		assert URLs.Get_HREF_Hyperlinks(HTML_content)
				.equals(
							  "http://www.wiprodigital.com"
							+ "\n"
							+ "http://wiprodigital.com" + "\n");

		// One good link and one not recognizable document
		HTML_content 
			=    "<a href=\"http://www.wiprodigital.com\">"
			   + "\n"
			   + "<a src=\"http://wiprodigital.com\">";

		assert URLs.Get_HREF_Hyperlinks(HTML_content)
				.equals("http://www.wiprodigital.com" + "\n");

	}
	
	
	/**
	 * Note Non UNIT
	 * Depends on UNIT Is_Hyperlink()
	 * Integration Tests non Unit method Get_Scripts_Hyperlinks, 
	 * which returns a string with hyperlinks refered to by the anchor spec, separated by newline characters.
	 * Hyperlinks are extracted when detecting the <a' tag and the 'href' HTML attribute term
	 * An empty string is returned if no links are found. 
	 */
	@Test
	public final void Intg_Test_Get_Scripts_Hyperlinks()
	{
		String HTML_content = "";

		// Empty document
		assert URLs.Get_Scripts_Hyperlinks(HTML_content).equals("");
		
		// One link document
		HTML_content = "<script src=\"http://www.wiprodigital.com/scripts/bootstrap.min.js\">";
		assert URLs.Get_Scripts_Hyperlinks(HTML_content).equals("http://www.wiprodigital.com/scripts/bootstrap.min.js" + "\n");

		// One unrecognizable link document
		HTML_content = "<script href=\"http://www.wiprodigital.com/scripts/bootstrap.min.js\">";
		assert URLs.Get_Scripts_Hyperlinks(HTML_content).equals("");
		
		// Two link document
		HTML_content 
			=    "<script src=\"http://www.wiprodigital.com/scripts/bootstrap.min.js\">"
			   + "\n"
			   + "<script src=\"http://wiprodigital.com/scripts/bootstrap.min.js\">";

		assert URLs.Get_Scripts_Hyperlinks(HTML_content)
				.equals(
							  "http://www.wiprodigital.com/scripts/bootstrap.min.js"
							+ "\n"
							+ "http://wiprodigital.com/scripts/bootstrap.min.js" + "\n");

		// One good link and one not recognizable document
		HTML_content 
			=    "<script src=\"http://www.wiprodigital.com/scripts/bootstrap.min.js\">"
			   + "\n"
			   + "<script href=\"http://wiprodigital.com/scripts/bootstrap.min.js\">";

		assert URLs.Get_Scripts_Hyperlinks(HTML_content)
				.equals("http://www.wiprodigital.com/scripts/bootstrap.min.js" + "\n");

	}
	
	
	
	
	
	
	
	
	// TO DO: future expansion
	/**
	 * Test method for {@link Text_Extraction.URLs#Validate_URL_Address(java.lang.String)}.
	 */
	/**
	@Test
	public void Test_Validate_URL_Address() {
		URL_validity.Valid_URL_Address_Test();
		URL_validity.Invalid_URL_Address_Test();

	}
	
**/

	// TO DO: future expansion
	/**
	 * Test method Get_Enclosed_Hyperlinks()
	 */
	/**
	@Test
	public void Test_Validate_URL_Address() {
		URL_validity.Valid_URL_Address_Test();
		URL_validity.Invalid_URL_Address_Test();

	}
	
**/
	
}

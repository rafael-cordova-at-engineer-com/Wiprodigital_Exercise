package Text_Extraction_Testing;

import org.junit.Test;

// TO DO: future addition of full validation tests
/**
 * Class to perform complete validation of functions processing hyperlinks. 
 **/


public class URLsValidationTestCases {
	
	/**
	 * Test valid URL address 
	 */
	/**
	@Test
	public void Get_URL_Host_Test() {	
		assert URLs.Get_URL_Domain("http://www.wiprodigital.com").equals("www.wiprodigital.com");
		assert URLs.Get_URL_Domain("http://www.wiprodigital.com/").equals("www.wiprodigital.com/");
	}
	 **/

	
	/**
	 * Test valid URL address 
	 **/
	@Test
	public void Valid_URL_Address_Test()
	{
		
		// TO DO:
		/**
		// Verify that it recognizes valid domains
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.com");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.org");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.edu");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.net");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.int");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.gov");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.mil");
		assert true == URLs.Validate_URL_Address("http://www.wiprodigital.arpa");
		 **/	
		/**
		// Verify that it recognizes valid protocols
		// http already verified via valid domains verification
		assert true == URLs.Validate_URL_Address("https://www.wiprodigital.com");
		assert true == URLs.Validate_URL_Address("ftp://www.wiprodigital.com");
		assert true == URLs.Validate_URL_Address("file://www.wiprodigital.com");
		assert true == URLs.Validate_URL_Address("ssh://www.wiprodigital.com");
		assert true == URLs.Validate_URL_Address("gopher://www.wiprodigital.com");
		assert true == URLs.Validate_URL_Address("telnet://www.wiprodigital.com");		
		**/
		
		/**
		//Verify that it recognizes valid server specifications
		// Explicit server name already verified via valid protocols and domains verification
		// Verify for implicit server
		assert true == URLs.Validate_URL_Address("https://wiprodigital.com");
		// Verify for non default server name
		assert true == URLs.Validate_URL_Address("https://servername.wiprodigital.com");
		
		**/
		
	}

	
	/**
	 * Test invalid URL address 
	 **/
	@Test
	public void Invalid_URL_Address_Test()
	{
		/**
		assert false == URLs.Validate_URL_Address("http:/www.wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http:///www.wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http://www.wiprodigital.com");
		
		assert false == URLs.Validate_URL_Address("http://www..wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http:/www.wiprodigital.comm");		
		assert false == URLs.Validate_URL_Address("http://www.wiprodigital.dom");
		
		assert false == URLs.Validate_URL_Address("http//www.wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http:://www.wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http;//www.wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http://www.wiprodigital.com.");
		
		assert false == URLs.Validate_URL_Address("http://www;wiprodigital.com");
		assert false == URLs.Validate_URL_Address("http://www;wiprodigital;com");		
		**/
	}

}

// HubSpot Script Loader. Please do not block this resource. See more: http://hubs.ly/H0702_H0

(function (id, src) {
  if (document.getElementById(id)) { return; }
  var js = document.createElement('script');
  js.src = src;
  js.type = 'text/javascript';
  js.id = id;
  var e = document.getElementsByTagName('script')[0];
  e.parentNode.insertBefore(js, e);
})('hs-analytics', '//js.hs-analytics.net/analytics/1542869400000/621527.js');

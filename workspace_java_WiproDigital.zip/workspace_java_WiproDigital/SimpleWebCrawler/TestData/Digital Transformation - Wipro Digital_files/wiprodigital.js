$(document).ready(function() {
    Modernizr.touch || $(".wd-navbar-nav .wd-navbar-nav-elem").hover(function() {
        $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeIn(500)
    }, function() {
        $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeOut(500)
    }), $("#btnWDSearch").click(function() {
        var n = $("#WDsearchform input[name='post_type[]']:checked").length;
        if (0 == n) return $("#wdsferrormsg").fadeIn(), !1
    });
    $('#menu').slicknav({
        allowParentLinks: true,
        nestedParentLinks: false,
        appendTo: "#mobileMenu",
        closeOnClick: true,
        beforeOpen: function(trigger){
      if(!(trigger.hasClass('slicknav_btn'))){
        var that = trigger.parent().parent().children('ul');
          $('.slicknav_menu ul li.slicknav_open ul').each(function(){
              if($(this).get( 0 ) != that.get( 0 )){
                  $(this).slideUp().addClass('slicknav_hidden');
                  $(this).parent().removeClass('slicknav_open').addClass('slicknav_collapsed');
              }
          });
        }
      }
    });
    $('.navbar-toggle').click(function(e) {
        e.preventDefault();
        $('#menu').slicknav('toggle');
        $(".wd-navbar-container").css('background-color','#000');
        // home code
        $(".home .wd-navlogo-digital").stop().show(100);
        });
});
